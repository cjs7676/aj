package com.example.demo;

public class HelloWorldService {
public void sayhello() { System.out.println("Hello World");
}
}

